<!DOCTYPE html>
<html>
<head>
    <title>Dokumen</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            text-align: left;
            padding: 8px;
            border: 1px solid #ddd;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        th {
            background-color: black;
            color: white;
        }
        p. {
          background-color: #2196F3;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }
    </style>
</head>
<body>
<table>
  <tr>
    <th>No</th>
    <th>No. Rekening</th>
    <th>Customer</th>
    <th>Saldo</th>
  </tr>
  <tr>
    <td>1</td>
    <td>010</td>
    <td>Messi</td>
    <td>5000000</td>
  </tr>
  <tr>
    <td>2</td>
    <td>070</td>
    <td>Ronaldo</td>
    <td>10000000</td>
  </tr>
  <tr>
    <td>3</td>
    <td>123</td>
    <td>Neymar</td>
    <td>2000000</td>
  </tr>
</table>
<a  href="form.php">Back</a>
</body>
</html>
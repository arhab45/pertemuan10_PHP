<!DOCTYPE html>
<html>
<head>
    <title>Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        
        .p {
          text-align:center ;
        }

        .form-container {
            padding: 20px;
            width: 300px;
            margin: 0 auto;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-left: 4px solid #2196F3;
        }

        button[type="submit"] {
            background-color: #2196F3;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        button[type="submit"]:hover {
            background-color: #4CAF50;
        }
    </style>
</head>
<body>
<h1 class="p">Form Account Bank</h1>
<div class="form-container">
        <form method="post" action="hasil.php"> 
            <label for="nomor-rekening">Nomor Rekening</label>
            <input type="text" id="nomor-rekening" name="nomor-rekening">

            <label for="nama-customer">Nama Customer</label>
            <input type="text" id="nama-customer" name="nama-customer">

            <label for="saldo-awal">Saldo Awal</label>
            <input type="text" id="saldo-awal" name="saldo-awal">

            <button  type="submit">Submit</button>
        </form>
    </div>

</body>
</html>